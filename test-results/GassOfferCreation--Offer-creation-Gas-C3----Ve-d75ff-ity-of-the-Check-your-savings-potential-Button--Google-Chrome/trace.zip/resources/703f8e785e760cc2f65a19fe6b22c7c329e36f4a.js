"use strict";(self.webpackChunkremind_me_frontend=self.webpackChunkremind_me_frontend||[]).push([[6344],{16344:function(e,n,f){f.r(n),n.default={}}}]);
//# sourceMappingURL=6344.0299e071.chunk.js.map